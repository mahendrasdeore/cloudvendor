package com.jen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAndJenkinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
