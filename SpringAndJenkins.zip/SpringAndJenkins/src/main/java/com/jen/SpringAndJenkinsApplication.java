package com.jen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAndJenkinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAndJenkinsApplication.class, args);
	}

}
