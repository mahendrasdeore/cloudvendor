package com.cloudvendor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudVendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
